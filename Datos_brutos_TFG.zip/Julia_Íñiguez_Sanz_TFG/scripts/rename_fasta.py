from Bio import SeqIO

input_fasta = "all_UCP1_aligment.fas"
output_fasta = "UCP1_shortnames.fasta"
output_phylip = "UCP1_phylip_clean.phy"

records = []
used = set()

# --- renombrar secuencias ---
for record in SeqIO.parse(input_fasta, "fasta"):
    # separar género y especie
    parts = record.description.split()

    if len(parts) >= 2:
        genus = parts[0]
        species = parts[1]
        new_name = genus[:3] + species[:5]  # max 8 chars
    else:
        new_name = record.id[:8]

    # asegurarse de que sea único
    if new_name in used:
        i = 1
        while f"{new_name[:8]}{i}" in used:
            i += 1
        new_name = f"{new_name[:8]}{i}"

    used.add(new_name)
    record.id = new_name
    record.description = ""
    records.append(record)

# --- guardar FASTA renombrado ---
SeqIO.write(records, output_fasta, "fasta")
print("Archivo renombrado con género+especie (FASTA) listo")

# --- generar PHYLIP compatible con PAML ---
with open(output_phylip, "w") as phylip_file:
    nseq = len(records)
    nsites = len(records[0].seq)
    phylip_file.write(f"{nseq} {nsites}\n")

    for rec in records:
        # quitar espacios en la secuencia
        seq_str = str(rec.seq).replace(" ", "").replace("\n", "")
        # nombre de max 10 caracteres, alineado a la izquierda
        phylip_file.write(f"{rec.id[:10].ljust(10)}  {seq_str}\n")

print(f"Archivo PHYLIP para PAML generado: {output_phylip}")
from Bio import SeqIO

input_fasta = "all_UCP1_aligment.fas"
output_fasta = "UCP1_shortnames.fasta"

records = []
used = set()

for record in SeqIO.parse(input_fasta, "fasta"):
    # separar género y especie
    parts = record.description.split()

    if len(parts) >= 2:
        genus = parts[0]
        species = parts[1]
        new_name = genus[:3] + species[:5]
    else:
        new_name = record.id[:8]

    # asegurarse de que es único
    if new_name in used:
        i = 1
        while f"{new_name[:8]}{i}" in used:
            i += 1
        new_name = f"{new_name[:8]}{i}"

    used.add(new_name)
    record.id = new_name
    record.description = ""
    records.append(record)

SeqIO.write(records, output_fasta, "fasta")
print("Archivo renombrado con género+especie (PHYLIP-safe)")


